setwd("/Users/sharan/Downloads/IT24102361_Lab06")
getwd()

# Exercise 1
n <- 50
p <- 0.85


cat("X ~ Binomial(", n, ",", p, ")\n")


prob_47_or_more <- pbinom(46, size=n, prob=p, lower.tail=FALSE)
cat("P(X >= 47) =", prob_47_or_more, "\n")


# Exercise 2
lambda <- 12
cat("X ~ Poisson(", lambda, ")\n")



